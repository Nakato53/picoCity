function GameManagerNew()
	gamestate = {}
end